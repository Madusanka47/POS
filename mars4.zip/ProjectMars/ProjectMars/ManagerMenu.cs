﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace ProjectMars
{
    public partial class ManagerMenu : ProjectMars.ParentForm1
    {
        public ManagerMenu()
        {
            InitializeComponent();
        }

        private void ManagerMenu_Load(object sender, EventArgs e)
        {

        }

        private void metroTile1_Click(object sender, EventArgs e)
        {

        }

        private void metroPanel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void metroTile4_Click(object sender, EventArgs e)
        {
            ReportViewerM R = new ReportViewerM();
            R.ShowDialog();
        }

        private void metroTile2_Click(object sender, EventArgs e)
        {
           EmployeeUpdateM E = new EmployeeUpdateM();
           E.ShowDialog();
           
        }
    }
}
