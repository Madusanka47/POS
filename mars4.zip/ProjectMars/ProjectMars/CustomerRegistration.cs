﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProjectMars
{
    public partial class CustomerRegistration : MetroFramework.Forms.MetroForm
    {
        public CustomerRegistration()
        {
            InitializeComponent();
        }

        private void checkout_Load(object sender, EventArgs e)
        {

        }
    }
}
