﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProjectMars
{
    public partial class CheckoutForm : MetroFramework.Forms.MetroForm
    {
        CashRegister ch = new CashRegister();
       // CashRegister CF;
       public double  pass;
        string str;
        public CheckoutForm()
        {
            InitializeComponent();
           // CF = FC;
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
           
        }

        private void button1_Click(object sender, EventArgs e)
        {

          //  this.Hide();
          //  CF.Show();

    }

        private void CheckoutForm_Load(object sender, EventArgs e)
        {

            txt_tot.Text = pass.ToString();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if(cmb_pay.SelectedIndex==0)
            {
                txt_cv.ReadOnly = true;
                txt_type.ReadOnly = true;
                txt_amo.ReadOnly = false;
            }
            else if(cmb_pay.SelectedIndex==1)
            {

             //  string a = txt_cv.Text;
            //  str =a.Substring(0,5);
              //  txt_amo.Text = a;


            }
            else if(cmb_pay.SelectedIndex==2)
            {
                txt_cv.ReadOnly = false;
                txt_type.ReadOnly = false;
                txt_amo.ReadOnly = false;
            }
            else if(cmb_pay.SelectedIndex==3)
            {
                txt_amo.ReadOnly = true;
                txt_cv.ReadOnly = false;
                txt_type.ReadOnly = false;
            }
        }
    }
}
